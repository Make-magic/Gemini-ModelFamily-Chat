// Re-export modularized prompts
export * from './prompts/deepSearch';
export * from './prompts/canvas';

export const DEFAULT_SYSTEM_INSTRUCTION = '';
